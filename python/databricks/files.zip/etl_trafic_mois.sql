-- =============================================================================
-- ETL TRAFIC POSTAL — GRAIN MOIS
-- =============================================================================
--
-- OBJECTIF
-- --------
-- Agrège les données de trafic granulaires mensuelles vers une table cible
-- pivotée par MOIS × SITE (une colonne par catégorie métier).
--
-- DIFFÉRENCES vs GRAINS JOUR / SEMAINE
-- ------------------------------------
--   - Colonne de mesure = `nb_objet_retenu`
--   - Clé temporelle    = (co_annee_comptage, co_mois_comptage)
--   - Partitionnement   = co_annee_comptage
--
-- PARAMÈTRES DATABRICKS (widgets)
-- -------------------------------
--   :mode               STRING  ("initial" | "backfill" | "incremental")
--   :annee_debut        INT     ex. 2025
--   :annee_fin          INT     ex. 2025 (incluse)
--   :mois_refresh       INT     nb mois pour incremental (ex. 3)
--   :source_table       STRING  "ppd_dd_kairos_int.03_gold.g_mdp_trafics_mois_actualise"
--   :target_table       STRING  "ppd_dd_kairos_int.03_gold.g_trafic_site_mois"
-- =============================================================================


-- -----------------------------------------------------------------------------
-- ÉTAPE 1 — CRÉATION DE LA TABLE CIBLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS IDENTIFIER(:target_table) (
    co_annee_comptage           INT       NOT NULL,
    co_mois_comptage            INT       NOT NULL,
    co_regate                   STRING    NOT NULL,
    type_site                   STRING,
    trafic_oo                   BIGINT,
    presse_mecanisee            BIGINT,
    presse_locale_declarative   BIGINT,
    presse_viapost_hors_meca    BIGINT,
    trafic_os                   BIGINT,
    trafic_ip                   BIGINT,
    trafic_colis                BIGINT,
    trafic_ppi                  BIGINT,
    dh_maj                      TIMESTAMP
)
USING DELTA
PARTITIONED BY (co_annee_comptage)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
);


-- -----------------------------------------------------------------------------
-- ÉTAPE 2A — MODE "initial"
-- -----------------------------------------------------------------------------
INSERT OVERWRITE IDENTIFIER(:target_table)
SELECT
    j.co_annee_comptage,
    j.co_mois_comptage,
    j.co_regate,
    j.lb_type_entite_regate_court AS type_site,

    /* Courrier OO */
    SUM(CASE
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('TI_COL_MENAGE','TI_COL_CEDEX') THEN j.nb_objet_retenu
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'R' THEN j.nb_objet_retenu
        WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
             AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'R' THEN j.nb_objet_retenu
        ELSE 0
    END) AS trafic_oo,

    /* Presse mécanisée */
    SUM(CASE
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'P' THEN j.nb_objet_retenu
        WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
             AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'P' THEN j.nb_objet_retenu
        ELSE 0
    END) AS presse_mecanisee,

    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'PPLP0' THEN j.nb_objet_retenu ELSE 0 END) AS presse_locale_declarative,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage IN ('1POP0','VPIP0') THEN j.nb_objet_retenu ELSE 0 END) AS presse_viapost_hors_meca,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'TRSP1' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_os,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'IMPJ' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_ip,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'TLOP1' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_colis,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage IN ('VQQP0','2QNP1','2QQP1') THEN j.nb_objet_retenu ELSE 0 END) AS trafic_ppi,

    current_timestamp() AS dh_maj

FROM IDENTIFIER(:source_table) j
WHERE j.co_annee_comptage >= :annee_debut
  AND j.co_annee_comptage <= :annee_fin
  AND (
      j.co_process IN ('VT','DT')
      OR j.co_comptage IN (
          'TI_COL_MENAGE','TI_COL_CEDEX','OR4PM','OR4PX',
          'TRSP1','IMPJ','TLOP1',
          'VQQP0','2QNP1','2QQP1',
          'PPLP0','1POP0','VPIP0'
      )
  )
GROUP BY
    j.co_annee_comptage,
    j.co_mois_comptage,
    j.co_regate,
    j.lb_type_entite_regate_court;


-- -----------------------------------------------------------------------------
-- ÉTAPE 2B — MODE "backfill"  (replaceWhere sur plage d'années)
-- -----------------------------------------------------------------------------
INSERT OVERWRITE IDENTIFIER(:target_table)
REPLACE WHERE co_annee_comptage >= :annee_debut AND co_annee_comptage <= :annee_fin
SELECT
    j.co_annee_comptage,
    j.co_mois_comptage,
    j.co_regate,
    j.lb_type_entite_regate_court AS type_site,
    SUM(CASE
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('TI_COL_MENAGE','TI_COL_CEDEX') THEN j.nb_objet_retenu
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'R' THEN j.nb_objet_retenu
        WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
             AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'R' THEN j.nb_objet_retenu
        ELSE 0
    END) AS trafic_oo,
    SUM(CASE
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'P' THEN j.nb_objet_retenu
        WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
             AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'P' THEN j.nb_objet_retenu
        ELSE 0
    END) AS presse_mecanisee,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'PPLP0' THEN j.nb_objet_retenu ELSE 0 END) AS presse_locale_declarative,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage IN ('1POP0','VPIP0') THEN j.nb_objet_retenu ELSE 0 END) AS presse_viapost_hors_meca,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'TRSP1' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_os,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'IMPJ' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_ip,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'TLOP1' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_colis,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage IN ('VQQP0','2QNP1','2QQP1') THEN j.nb_objet_retenu ELSE 0 END) AS trafic_ppi,
    current_timestamp() AS dh_maj
FROM IDENTIFIER(:source_table) j
WHERE j.co_annee_comptage >= :annee_debut
  AND j.co_annee_comptage <= :annee_fin
  AND (
      j.co_process IN ('VT','DT')
      OR j.co_comptage IN (
          'TI_COL_MENAGE','TI_COL_CEDEX','OR4PM','OR4PX',
          'TRSP1','IMPJ','TLOP1',
          'VQQP0','2QNP1','2QQP1',
          'PPLP0','1POP0','VPIP0'
      )
  )
GROUP BY
    j.co_annee_comptage, j.co_mois_comptage,
    j.co_regate, j.lb_type_entite_regate_court;


-- -----------------------------------------------------------------------------
-- ÉTAPE 2C — MODE "incremental"  (MERGE sur N derniers mois)
-- -----------------------------------------------------------------------------
-- Filtre via add_months sur la date du jour, ramenée au 1er du mois limite.
-- -----------------------------------------------------------------------------
MERGE INTO IDENTIFIER(:target_table) AS tgt
USING (
    SELECT
        j.co_annee_comptage,
        j.co_mois_comptage,
        j.co_regate,
        j.lb_type_entite_regate_court AS type_site,
        SUM(CASE
            WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                 AND j.co_comptage IN ('TI_COL_MENAGE','TI_COL_CEDEX') THEN j.nb_objet_retenu
            WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                 AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'R' THEN j.nb_objet_retenu
            WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
                 AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'R' THEN j.nb_objet_retenu
            ELSE 0
        END) AS trafic_oo,
        SUM(CASE
            WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                 AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'P' THEN j.nb_objet_retenu
            WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
                 AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'P' THEN j.nb_objet_retenu
            ELSE 0
        END) AS presse_mecanisee,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage = 'PPLP0' THEN j.nb_objet_retenu ELSE 0 END) AS presse_locale_declarative,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage IN ('1POP0','VPIP0') THEN j.nb_objet_retenu ELSE 0 END) AS presse_viapost_hors_meca,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage = 'TRSP1' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_os,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage = 'IMPJ' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_ip,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage = 'TLOP1' THEN j.nb_objet_retenu ELSE 0 END) AS trafic_colis,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage IN ('VQQP0','2QNP1','2QQP1') THEN j.nb_objet_retenu ELSE 0 END) AS trafic_ppi,
        current_timestamp() AS dh_maj
    FROM IDENTIFIER(:source_table) j
    /* On garde les N derniers mois : on compare (annee*100+mois) */
    WHERE (j.co_annee_comptage * 100 + j.co_mois_comptage) >=
          (year(add_months(current_date(), -:mois_refresh)) * 100
           + month(add_months(current_date(), -:mois_refresh)))
      AND (
          j.co_process IN ('VT','DT')
          OR j.co_comptage IN (
              'TI_COL_MENAGE','TI_COL_CEDEX','OR4PM','OR4PX',
              'TRSP1','IMPJ','TLOP1',
              'VQQP0','2QNP1','2QQP1',
              'PPLP0','1POP0','VPIP0'
          )
      )
    GROUP BY
        j.co_annee_comptage, j.co_mois_comptage,
        j.co_regate, j.lb_type_entite_regate_court
) AS src
ON  tgt.co_annee_comptage = src.co_annee_comptage
AND tgt.co_mois_comptage  = src.co_mois_comptage
AND tgt.co_regate         = src.co_regate
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;


-- -----------------------------------------------------------------------------
-- ÉTAPE 3 — CONTRÔLE QUALITÉ
-- -----------------------------------------------------------------------------
SELECT
    MIN(co_annee_comptage * 100 + co_mois_comptage) AS periode_min,
    MAX(co_annee_comptage * 100 + co_mois_comptage) AS periode_max,
    COUNT(DISTINCT co_regate) AS nb_sites,
    COUNT(*) AS nb_lignes,
    SUM(trafic_oo + presse_mecanisee + presse_locale_declarative +
        presse_viapost_hors_meca + trafic_os + trafic_ip +
        trafic_colis + trafic_ppi) AS trafic_total_global
FROM IDENTIFIER(:target_table)
WHERE co_annee_comptage >= :annee_debut AND co_annee_comptage <= :annee_fin;


-- -----------------------------------------------------------------------------
-- ÉTAPE 4 — REQUÊTE DE CONSOMMATION (exemple)
-- -----------------------------------------------------------------------------
-- SELECT *
-- FROM IDENTIFIER(:target_table)
-- WHERE co_regate        = :regate
--   AND co_annee_comptage = :annee
-- ORDER BY co_mois_comptage;


-- -----------------------------------------------------------------------------
-- ÉTAPE 5 — OPTIMISATION
-- -----------------------------------------------------------------------------
-- OPTIMIZE IDENTIFIER(:target_table) ZORDER BY (co_regate);
-- VACUUM   IDENTIFIER(:target_table) RETAIN 168 HOURS;
