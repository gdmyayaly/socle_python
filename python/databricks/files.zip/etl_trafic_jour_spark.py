# Databricks notebook source
# MAGIC %md
# MAGIC # ETL Trafic Postal — Grain JOUR
# MAGIC
# MAGIC **Objectif :** agréger les données de trafic granulaires de la couche source
# MAGIC vers une table cible pivotée par **jour × site**, avec les catégories métier
# MAGIC en colonnes (courrier OO, presse mécanisée, colis, OS, IP, PPI, etc.).
# MAGIC
# MAGIC **Modes d'exécution :**
# MAGIC - `initial`     : premier chargement (OVERWRITE complet)
# MAGIC - `backfill`    : rejouer une période précise (remplace chirurgicalement via `replaceWhere`)
# MAGIC - `incremental` : refresh quotidien sur les N derniers jours (MERGE upsert)
# MAGIC
# MAGIC **Paramétrage :** toute la logique métier (codes, types de sites, process) est
# MAGIC centralisée dans la section `CONFIG MÉTIER`. Pour ajouter un nouveau flux,
# MAGIC il suffit de modifier le dictionnaire `CODES`.

# COMMAND ----------
# MAGIC %md ## 1. Widgets — paramètres du Job

# COMMAND ----------
dbutils.widgets.dropdown("mode", "incremental", ["initial", "incremental", "backfill"], "Mode d'exécution")
dbutils.widgets.text("date_debut", "2025-01-01", "Date début (YYYY-MM-DD)")
dbutils.widgets.text("date_fin",   "2026-01-01", "Date fin exclusive (YYYY-MM-DD)")
dbutils.widgets.text("jours_refresh", "7", "Nb jours à rafraîchir (incremental)")
dbutils.widgets.text("source_table", "ppd_dd_kairos_int.03_gold.g_mdp_trafics_jour_actualise", "Table source")
dbutils.widgets.text("target_table", "ppd_dd_kairos_int.03_gold.g_trafic_site_jour",            "Table cible")

MODE          = dbutils.widgets.get("mode")
DATE_DEBUT    = dbutils.widgets.get("date_debut")
DATE_FIN      = dbutils.widgets.get("date_fin")
JOURS_REFRESH = int(dbutils.widgets.get("jours_refresh"))
SOURCE_TABLE  = dbutils.widgets.get("source_table")
TARGET_TABLE  = dbutils.widgets.get("target_table")

print(f"Mode         = {MODE}")
print(f"Source       = {SOURCE_TABLE}")
print(f"Cible        = {TARGET_TABLE}")

# COMMAND ----------
# MAGIC %md ## 2. CONFIG MÉTIER — *à modifier ici pour tout ajout/changement*

# COMMAND ----------
# Colonne de mesure dans la source (⚠ diffère entre jour / semaine / mois)
MEASURE_COL = "trafic_reel"

# Types d'entités Regate
SITES_DISTRIB    = ["PDC1", "PDC2", "PPDC"]   # plateformes de distribution (aval)
SITES_TRI        = ["PIC", "CTC"]             # centres de tri (amont)
PROCESS_COURRIER = ["VT", "DT"]               # processus valides pour courrier/presse sur PIC/CTC

# Catégories métier → codes `co_comptage` associés
CODES = {
    "oo_menage_cedex": ["TI_COL_MENAGE", "TI_COL_CEDEX"],
    "oo_or4":          ["OR4PM", "OR4PX"],
    "presse_locale":   ["PPLP0"],
    "presse_viapost":  ["1POP0", "VPIP0"],
    "os":              ["TRSP1"],
    "ip":              ["IMPJ"],
    "colis":           ["TLOP1"],
    "ppi":             ["VQQP0", "2QNP1", "2QQP1"],
}

# Liste blanche globale (pré-filtre de performance)
CODES_WHITELIST = sum(CODES.values(), [])

# COMMAND ----------
# MAGIC %md ## 3. Création de la table cible (idempotent)

# COMMAND ----------
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {TARGET_TABLE} (
    da_comptage                 DATE      NOT NULL,
    co_regate                   STRING    NOT NULL,
    type_site                   STRING,
    trafic_oo                   BIGINT,
    presse_mecanisee            BIGINT,
    presse_locale_declarative   BIGINT,
    presse_viapost_hors_meca    BIGINT,
    trafic_os                   BIGINT,
    trafic_ip                   BIGINT,
    trafic_colis                BIGINT,
    trafic_ppi                  BIGINT,
    dh_maj                      TIMESTAMP
)
USING DELTA
PARTITIONED BY (da_comptage)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
)
""")

# COMMAND ----------
# MAGIC %md ## 4. Détermination de la fenêtre de traitement

# COMMAND ----------
from datetime import date, timedelta

def determiner_fenetre(mode: str):
    if mode in ("initial", "backfill"):
        return DATE_DEBUT, DATE_FIN
    elif mode == "incremental":
        debut = (date.today() - timedelta(days=JOURS_REFRESH)).isoformat()
        fin   = (date.today() + timedelta(days=1)).isoformat()
        return debut, fin
    raise ValueError(f"Mode inconnu : {mode}")

debut, fin = determiner_fenetre(MODE)
print(f"Fenêtre traitée = [{debut} ; {fin}[")

# COMMAND ----------
# MAGIC %md ## 5. Lecture source + pré-filtre (whitelist)

# COMMAND ----------
from pyspark.sql import functions as F

df_source = (
    spark.table(SOURCE_TABLE)
         .filter(F.col("da_comptage") >= F.lit(debut))
         .filter(F.col("da_comptage") <  F.lit(fin))
         .filter(
             F.col("co_process").isin(PROCESS_COURRIER) |
             F.col("co_comptage").isin(CODES_WHITELIST)
         )
)

# COMMAND ----------
# MAGIC %md ## 6. Agrégation : pivot silver-like → colonnes métier

# COMMAND ----------
from pyspark.sql import DataFrame

def agreger_trafic_jour(df: DataFrame, measure_col: str) -> DataFrame:
    """
    Pivote le DataFrame source en un DataFrame agrégé par jour × site,
    avec une colonne par catégorie métier. Fonction pure (testable en isolation).
    """
    def somme_si(condition):
        return F.sum(F.when(condition, F.col(measure_col)).otherwise(0))

    est_distrib = F.col("lb_type_entite_regate_court").isin(SITES_DISTRIB)
    est_tri     = F.col("lb_type_entite_regate_court").isin(SITES_TRI)
    process_cd  = F.col("co_process").isin(PROCESS_COURRIER)

    return (
        df.groupBy("da_comptage", "co_regate", "lb_type_entite_regate_court")
          .agg(
              # --- Courrier ordinaire (OO) ---
              somme_si(
                  (est_distrib & F.col("co_comptage").isin(CODES["oo_menage_cedex"])) |
                  (est_distrib & F.col("co_comptage").isin(CODES["oo_or4"]) & (F.col("co_type_objet") == "R")) |
                  (est_tri     & process_cd & (F.col("co_type_objet") == "R"))
              ).alias("trafic_oo"),

              # --- Presse mécanisée ---
              somme_si(
                  (est_distrib & F.col("co_comptage").isin(CODES["oo_or4"]) & (F.col("co_type_objet") == "P")) |
                  (est_tri     & process_cd & (F.col("co_type_objet") == "P"))
              ).alias("presse_mecanisee"),

              # --- Presse locale déclarative ---
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["presse_locale"]))
                  .alias("presse_locale_declarative"),

              # --- Presse Viapost hors méca ---
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["presse_viapost"]))
                  .alias("presse_viapost_hors_meca"),

              # --- Objets suivis (OS) ---
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["os"]))
                  .alias("trafic_os"),

              # --- Imprimés publicitaires (IP) ---
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["ip"]))
                  .alias("trafic_ip"),

              # --- Colis ---
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["colis"]))
                  .alias("trafic_colis"),

              # --- PPI / e-Paq ---
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["ppi"]))
                  .alias("trafic_ppi"),
          )
          .withColumnRenamed("lb_type_entite_regate_court", "type_site")
          .withColumn("dh_maj", F.current_timestamp())
    )

df_target = agreger_trafic_jour(df_source, MEASURE_COL)

# COMMAND ----------
# MAGIC %md ## 7. Écriture vers la cible (stratégie selon le mode)

# COMMAND ----------
from delta.tables import DeltaTable

def ecrire_cible(df: DataFrame, mode: str):
    if mode == "initial":
        # Premier chargement : on écrase tout
        (df.write
            .format("delta").mode("overwrite")
            .option("overwriteSchema", "true")
            .partitionBy("da_comptage")
            .saveAsTable(TARGET_TABLE))
        print("✅ Chargement initial terminé")

    elif mode == "backfill":
        # Remplace uniquement la fenêtre concernée (précis et sûr)
        (df.write
            .format("delta").mode("overwrite")
            .option("replaceWhere", f"da_comptage >= '{debut}' AND da_comptage < '{fin}'")
            .partitionBy("da_comptage")
            .saveAsTable(TARGET_TABLE))
        print(f"✅ Backfill terminé sur [{debut} ; {fin}[")

    elif mode == "incremental":
        # Upsert pour gérer les retardataires sans dupliquer
        cible = DeltaTable.forName(spark, TARGET_TABLE)
        (cible.alias("tgt")
              .merge(
                  df.alias("src"),
                  "tgt.da_comptage = src.da_comptage AND tgt.co_regate = src.co_regate"
              )
              .whenMatchedUpdateAll()
              .whenNotMatchedInsertAll()
              .execute())
        print(f"✅ Incrémental terminé (J-{JOURS_REFRESH} → aujourd'hui)")

ecrire_cible(df_target, MODE)

# COMMAND ----------
# MAGIC %md ## 8. Contrôle qualité

# COMMAND ----------
display(spark.sql(f"""
    SELECT
        MIN(da_comptage) AS date_min,
        MAX(da_comptage) AS date_max,
        COUNT(DISTINCT co_regate) AS nb_sites,
        COUNT(*) AS nb_lignes,
        SUM(trafic_oo + presse_mecanisee + presse_locale_declarative +
            presse_viapost_hors_meca + trafic_os + trafic_ip +
            trafic_colis + trafic_ppi) AS trafic_total_global
    FROM {TARGET_TABLE}
    WHERE da_comptage >= '{debut}' AND da_comptage < '{fin}'
"""))

# COMMAND ----------
# MAGIC %md ## 9. Optimisation (à lancer 1×/semaine dans un Job séparé)

# COMMAND ----------
# spark.sql(f"OPTIMIZE {TARGET_TABLE} ZORDER BY (co_regate)")
# spark.sql(f"VACUUM {TARGET_TABLE} RETAIN 168 HOURS")
