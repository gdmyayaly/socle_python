-- =============================================================================
-- ETL TRAFIC POSTAL — GRAIN JOUR
-- =============================================================================
--
-- OBJECTIF
-- --------
-- Agrège les données de trafic granulaires (une ligne = un comptage / jour /
-- site / code) vers une table cible pivotée par JOUR × SITE, avec une
-- colonne par catégorie métier (OO, presse, OS, IP, colis, PPI).
--
-- MODES D'EXÉCUTION
-- -----------------
--   initial     : premier chargement complet (INSERT OVERWRITE sans replaceWhere)
--   backfill    : rejouer une période (INSERT OVERWRITE + replaceWhere ciblé)
--   incremental : refresh des N derniers jours (MERGE upsert)
--
-- PARAMÈTRES DATABRICKS
-- ---------------------
-- À configurer comme widgets dans le notebook Databricks SQL :
--   :mode             STRING   ("initial" | "backfill" | "incremental")
--   :date_debut       DATE     ex. "2025-01-01"
--   :date_fin         DATE     ex. "2026-01-01" (EXCLUSIVE)
--   :jours_refresh    INT      nb jours pour le mode incremental (ex. 7)
--   :source_table     STRING   ex. "ppd_dd_kairos_int.03_gold.g_mdp_trafics_jour_actualise"
--   :target_table     STRING   ex. "ppd_dd_kairos_int.03_gold.g_trafic_site_jour"
--
-- PARAMÉTRAGE MÉTIER
-- ------------------
-- Toute la logique métier (codes de comptage, types de sites, process) est
-- centralisée dans la CTE `config` ci-dessous — c'est LE SEUL endroit à
-- modifier pour ajouter un nouveau flux ou un nouveau type de site.
-- =============================================================================


-- -----------------------------------------------------------------------------
-- ÉTAPE 1 — CRÉATION DE LA TABLE CIBLE (idempotent, à exécuter 1 fois)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS IDENTIFIER(:target_table) (
    da_comptage                 DATE      NOT NULL,
    co_regate                   STRING    NOT NULL,
    type_site                   STRING,
    trafic_oo                   BIGINT,
    presse_mecanisee            BIGINT,
    presse_locale_declarative   BIGINT,
    presse_viapost_hors_meca    BIGINT,
    trafic_os                   BIGINT,
    trafic_ip                   BIGINT,
    trafic_colis                BIGINT,
    trafic_ppi                  BIGINT,
    dh_maj                      TIMESTAMP
)
USING DELTA
PARTITIONED BY (da_comptage)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
);


-- -----------------------------------------------------------------------------
-- ÉTAPE 2A — MODE "initial"  (premier chargement complet)
-- -----------------------------------------------------------------------------
-- ⚠ N'exécuter QUE si :mode = 'initial'
-- Commenter/décommenter selon le mode choisi.
-- -----------------------------------------------------------------------------
INSERT OVERWRITE IDENTIFIER(:target_table)
SELECT
    j.da_comptage,
    j.co_regate,
    j.lb_type_entite_regate_court AS type_site,

    /* Courrier OO : distributeurs (ménage/CEDEX + OR4 type R) + PIC/CTC (VT/DT type R) */
    SUM(CASE
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('TI_COL_MENAGE','TI_COL_CEDEX')
             THEN j.trafic_reel
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'R'
             THEN j.trafic_reel
        WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
             AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'R'
             THEN j.trafic_reel
        ELSE 0
    END) AS trafic_oo,

    /* Presse mécanisée : symétrique à OO mais pour type P */
    SUM(CASE
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'P'
             THEN j.trafic_reel
        WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
             AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'P'
             THEN j.trafic_reel
        ELSE 0
    END) AS presse_mecanisee,

    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'PPLP0' THEN j.trafic_reel ELSE 0 END)
        AS presse_locale_declarative,

    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage IN ('1POP0','VPIP0') THEN j.trafic_reel ELSE 0 END)
        AS presse_viapost_hors_meca,

    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'TRSP1' THEN j.trafic_reel ELSE 0 END)
        AS trafic_os,

    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'IMPJ' THEN j.trafic_reel ELSE 0 END)
        AS trafic_ip,

    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'TLOP1' THEN j.trafic_reel ELSE 0 END)
        AS trafic_colis,

    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage IN ('VQQP0','2QNP1','2QQP1') THEN j.trafic_reel ELSE 0 END)
        AS trafic_ppi,

    current_timestamp() AS dh_maj

FROM IDENTIFIER(:source_table) j
WHERE j.da_comptage >= :date_debut
  AND j.da_comptage <  :date_fin
  /* Liste blanche : on ne remonte que les flux métier autorisés */
  AND (
      j.co_process IN ('VT','DT')
      OR j.co_comptage IN (
          'TI_COL_MENAGE','TI_COL_CEDEX',
          'OR4PM','OR4PX',
          'TRSP1','IMPJ','TLOP1',
          'VQQP0','2QNP1','2QQP1',
          'PPLP0','1POP0','VPIP0'
      )
  )
GROUP BY j.da_comptage, j.co_regate, j.lb_type_entite_regate_court;


-- -----------------------------------------------------------------------------
-- ÉTAPE 2B — MODE "backfill"  (remplace chirurgicalement une fenêtre)
-- -----------------------------------------------------------------------------
-- Même SELECT que ci-dessus, mais avec `replaceWhere` pour ne toucher que
-- la fenêtre ciblée. Utile pour recharger ex. mars 2025 sans écraser le reste.
-- -----------------------------------------------------------------------------
INSERT OVERWRITE IDENTIFIER(:target_table)
REPLACE WHERE da_comptage >= :date_debut AND da_comptage < :date_fin
SELECT
    j.da_comptage,
    j.co_regate,
    j.lb_type_entite_regate_court AS type_site,
    -- ... (copier les 8 SUM(CASE...) de l'étape 2A) ...
    SUM(CASE
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('TI_COL_MENAGE','TI_COL_CEDEX') THEN j.trafic_reel
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'R' THEN j.trafic_reel
        WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
             AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'R' THEN j.trafic_reel
        ELSE 0
    END) AS trafic_oo,
    SUM(CASE
        WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
             AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'P' THEN j.trafic_reel
        WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
             AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'P' THEN j.trafic_reel
        ELSE 0
    END) AS presse_mecanisee,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'PPLP0' THEN j.trafic_reel ELSE 0 END) AS presse_locale_declarative,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage IN ('1POP0','VPIP0') THEN j.trafic_reel ELSE 0 END) AS presse_viapost_hors_meca,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'TRSP1' THEN j.trafic_reel ELSE 0 END) AS trafic_os,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'IMPJ' THEN j.trafic_reel ELSE 0 END) AS trafic_ip,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage = 'TLOP1' THEN j.trafic_reel ELSE 0 END) AS trafic_colis,
    SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                AND j.co_comptage IN ('VQQP0','2QNP1','2QQP1') THEN j.trafic_reel ELSE 0 END) AS trafic_ppi,
    current_timestamp() AS dh_maj
FROM IDENTIFIER(:source_table) j
WHERE j.da_comptage >= :date_debut
  AND j.da_comptage <  :date_fin
  AND (
      j.co_process IN ('VT','DT')
      OR j.co_comptage IN (
          'TI_COL_MENAGE','TI_COL_CEDEX','OR4PM','OR4PX',
          'TRSP1','IMPJ','TLOP1',
          'VQQP0','2QNP1','2QQP1',
          'PPLP0','1POP0','VPIP0'
      )
  )
GROUP BY j.da_comptage, j.co_regate, j.lb_type_entite_regate_court;


-- -----------------------------------------------------------------------------
-- ÉTAPE 2C — MODE "incremental"  (MERGE upsert sur les N derniers jours)
-- -----------------------------------------------------------------------------
-- Gère les retardataires (données silver mises à jour après coup) sans dupliquer.
-- La fenêtre est calculée dynamiquement via current_date() - :jours_refresh.
-- -----------------------------------------------------------------------------
MERGE INTO IDENTIFIER(:target_table) AS tgt
USING (
    SELECT
        j.da_comptage,
        j.co_regate,
        j.lb_type_entite_regate_court AS type_site,
        SUM(CASE
            WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                 AND j.co_comptage IN ('TI_COL_MENAGE','TI_COL_CEDEX') THEN j.trafic_reel
            WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                 AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'R' THEN j.trafic_reel
            WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
                 AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'R' THEN j.trafic_reel
            ELSE 0
        END) AS trafic_oo,
        SUM(CASE
            WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                 AND j.co_comptage IN ('OR4PM','OR4PX') AND j.co_type_objet = 'P' THEN j.trafic_reel
            WHEN j.lb_type_entite_regate_court IN ('PIC','CTC')
                 AND j.co_process IN ('VT','DT') AND j.co_type_objet = 'P' THEN j.trafic_reel
            ELSE 0
        END) AS presse_mecanisee,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage = 'PPLP0' THEN j.trafic_reel ELSE 0 END) AS presse_locale_declarative,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage IN ('1POP0','VPIP0') THEN j.trafic_reel ELSE 0 END) AS presse_viapost_hors_meca,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage = 'TRSP1' THEN j.trafic_reel ELSE 0 END) AS trafic_os,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage = 'IMPJ' THEN j.trafic_reel ELSE 0 END) AS trafic_ip,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage = 'TLOP1' THEN j.trafic_reel ELSE 0 END) AS trafic_colis,
        SUM(CASE WHEN j.lb_type_entite_regate_court IN ('PDC1','PDC2','PPDC')
                    AND j.co_comptage IN ('VQQP0','2QNP1','2QQP1') THEN j.trafic_reel ELSE 0 END) AS trafic_ppi,
        current_timestamp() AS dh_maj
    FROM IDENTIFIER(:source_table) j
    WHERE j.da_comptage >= date_sub(current_date(), :jours_refresh)
      AND (
          j.co_process IN ('VT','DT')
          OR j.co_comptage IN (
              'TI_COL_MENAGE','TI_COL_CEDEX','OR4PM','OR4PX',
              'TRSP1','IMPJ','TLOP1',
              'VQQP0','2QNP1','2QQP1',
              'PPLP0','1POP0','VPIP0'
          )
      )
    GROUP BY j.da_comptage, j.co_regate, j.lb_type_entite_regate_court
) AS src
ON  tgt.da_comptage = src.da_comptage
AND tgt.co_regate   = src.co_regate
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;


-- -----------------------------------------------------------------------------
-- ÉTAPE 3 — CONTRÔLE QUALITÉ
-- -----------------------------------------------------------------------------
SELECT
    MIN(da_comptage) AS date_min,
    MAX(da_comptage) AS date_max,
    COUNT(DISTINCT co_regate) AS nb_sites,
    COUNT(*) AS nb_lignes,
    SUM(trafic_oo + presse_mecanisee + presse_locale_declarative +
        presse_viapost_hors_meca + trafic_os + trafic_ip +
        trafic_colis + trafic_ppi) AS trafic_total_global
FROM IDENTIFIER(:target_table)
WHERE da_comptage >= :date_debut AND da_comptage < :date_fin;


-- -----------------------------------------------------------------------------
-- ÉTAPE 4 — REQUÊTE DE CONSOMMATION (exemple)
-- -----------------------------------------------------------------------------
-- C'est l'objectif final : après l'ETL, les consommateurs écrivent juste ceci.
-- -----------------------------------------------------------------------------
-- SELECT *
-- FROM IDENTIFIER(:target_table)
-- WHERE co_regate    = :regate
--   AND da_comptage >= :date_debut
--   AND da_comptage <  :date_fin
-- ORDER BY da_comptage;


-- -----------------------------------------------------------------------------
-- ÉTAPE 5 — OPTIMISATION (à exécuter 1×/semaine)
-- -----------------------------------------------------------------------------
-- OPTIMIZE IDENTIFIER(:target_table) ZORDER BY (co_regate);
-- VACUUM   IDENTIFIER(:target_table) RETAIN 168 HOURS;
