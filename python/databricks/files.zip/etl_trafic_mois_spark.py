# Databricks notebook source
# MAGIC %md
# MAGIC # ETL Trafic Postal — Grain MOIS
# MAGIC
# MAGIC **Objectif :** agréger les données de trafic granulaires de la couche source
# MAGIC vers une table cible pivotée par **mois × site**.
# MAGIC
# MAGIC **Différences vs grains JOUR / SEMAINE :**
# MAGIC - Colonne de mesure : `nb_objet_retenu` (comme le grain semaine).
# MAGIC - Clé temporelle : paire `(co_annee_comptage, co_mois_comptage)`.
# MAGIC - Partitionnement Delta sur `co_annee_comptage`.
# MAGIC
# MAGIC **Modes d'exécution :** `initial` / `backfill` / `incremental`
# MAGIC (incremental = N derniers mois).

# COMMAND ----------
# MAGIC %md ## 1. Widgets — paramètres du Job

# COMMAND ----------
dbutils.widgets.dropdown("mode", "incremental", ["initial", "incremental", "backfill"], "Mode d'exécution")
dbutils.widgets.text("annee_debut", "2025", "Année début (backfill/initial)")
dbutils.widgets.text("annee_fin",   "2025", "Année fin incluse (backfill/initial)")
dbutils.widgets.text("mois_refresh", "3", "Nb mois à rafraîchir (incremental)")
dbutils.widgets.text("source_table", "ppd_dd_kairos_int.03_gold.g_mdp_trafics_mois_actualise", "Table source")
dbutils.widgets.text("target_table", "ppd_dd_kairos_int.03_gold.g_trafic_site_mois",           "Table cible")

MODE          = dbutils.widgets.get("mode")
ANNEE_DEBUT   = int(dbutils.widgets.get("annee_debut"))
ANNEE_FIN     = int(dbutils.widgets.get("annee_fin"))
MOIS_REFRESH  = int(dbutils.widgets.get("mois_refresh"))
SOURCE_TABLE  = dbutils.widgets.get("source_table")
TARGET_TABLE  = dbutils.widgets.get("target_table")

print(f"Mode   = {MODE}")
print(f"Source = {SOURCE_TABLE}")
print(f"Cible  = {TARGET_TABLE}")

# COMMAND ----------
# MAGIC %md ## 2. CONFIG MÉTIER — *à modifier ici pour tout ajout/changement*

# COMMAND ----------
MEASURE_COL = "nb_objet_retenu"

SITES_DISTRIB    = ["PDC1", "PDC2", "PPDC"]
SITES_TRI        = ["PIC", "CTC"]
PROCESS_COURRIER = ["VT", "DT"]

CODES = {
    "oo_menage_cedex": ["TI_COL_MENAGE", "TI_COL_CEDEX"],
    "oo_or4":          ["OR4PM", "OR4PX"],
    "presse_locale":   ["PPLP0"],
    "presse_viapost":  ["1POP0", "VPIP0"],
    "os":              ["TRSP1"],
    "ip":              ["IMPJ"],
    "colis":           ["TLOP1"],
    "ppi":             ["VQQP0", "2QNP1", "2QQP1"],
}
CODES_WHITELIST = sum(CODES.values(), [])

# COMMAND ----------
# MAGIC %md ## 3. Création de la table cible (idempotent)

# COMMAND ----------
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {TARGET_TABLE} (
    co_annee_comptage           INT       NOT NULL,
    co_mois_comptage            INT       NOT NULL,
    co_regate                   STRING    NOT NULL,
    type_site                   STRING,
    trafic_oo                   BIGINT,
    presse_mecanisee            BIGINT,
    presse_locale_declarative   BIGINT,
    presse_viapost_hors_meca    BIGINT,
    trafic_os                   BIGINT,
    trafic_ip                   BIGINT,
    trafic_colis                BIGINT,
    trafic_ppi                  BIGINT,
    dh_maj                      TIMESTAMP
)
USING DELTA
PARTITIONED BY (co_annee_comptage)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
)
""")

# COMMAND ----------
# MAGIC %md ## 4. Détermination de la fenêtre de traitement

# COMMAND ----------
from datetime import date
from pyspark.sql import functions as F

def determiner_fenetre(mode: str):
    """Retourne le filtre PySpark selon le mode choisi."""
    if mode in ("initial", "backfill"):
        cond = (F.col("co_annee_comptage") >= ANNEE_DEBUT) & \
               (F.col("co_annee_comptage") <= ANNEE_FIN)
        libelle = f"années {ANNEE_DEBUT} → {ANNEE_FIN}"
        return cond, libelle

    elif mode == "incremental":
        # Calcul de l'année/mois limite il y a N mois
        today = date.today()
        total_mois = today.year * 12 + (today.month - 1) - MOIS_REFRESH
        annee_limite = total_mois // 12
        mois_limite  = (total_mois % 12) + 1
        cond = (
            (F.col("co_annee_comptage") > annee_limite) |
            ((F.col("co_annee_comptage") == annee_limite) & (F.col("co_mois_comptage") >= mois_limite))
        )
        libelle = f"{MOIS_REFRESH} derniers mois (depuis {annee_limite}-{mois_limite:02d})"
        return cond, libelle

    raise ValueError(f"Mode inconnu : {mode}")

filtre_fenetre, libelle_fenetre = determiner_fenetre(MODE)
print(f"Fenêtre traitée = {libelle_fenetre}")

# COMMAND ----------
# MAGIC %md ## 5. Lecture source + pré-filtre (whitelist)

# COMMAND ----------
df_source = (
    spark.table(SOURCE_TABLE)
         .filter(filtre_fenetre)
         .filter(
             F.col("co_process").isin(PROCESS_COURRIER) |
             F.col("co_comptage").isin(CODES_WHITELIST)
         )
)

# COMMAND ----------
# MAGIC %md ## 6. Agrégation : pivot → colonnes métier

# COMMAND ----------
from pyspark.sql import DataFrame

def agreger_trafic_mois(df: DataFrame, measure_col: str) -> DataFrame:
    def somme_si(condition):
        return F.sum(F.when(condition, F.col(measure_col)).otherwise(0))

    est_distrib = F.col("lb_type_entite_regate_court").isin(SITES_DISTRIB)
    est_tri     = F.col("lb_type_entite_regate_court").isin(SITES_TRI)
    process_cd  = F.col("co_process").isin(PROCESS_COURRIER)

    return (
        df.groupBy(
              "co_annee_comptage", "co_mois_comptage",
              "co_regate", "lb_type_entite_regate_court"
          )
          .agg(
              somme_si(
                  (est_distrib & F.col("co_comptage").isin(CODES["oo_menage_cedex"])) |
                  (est_distrib & F.col("co_comptage").isin(CODES["oo_or4"]) & (F.col("co_type_objet") == "R")) |
                  (est_tri     & process_cd & (F.col("co_type_objet") == "R"))
              ).alias("trafic_oo"),

              somme_si(
                  (est_distrib & F.col("co_comptage").isin(CODES["oo_or4"]) & (F.col("co_type_objet") == "P")) |
                  (est_tri     & process_cd & (F.col("co_type_objet") == "P"))
              ).alias("presse_mecanisee"),

              somme_si(est_distrib & F.col("co_comptage").isin(CODES["presse_locale"]))
                  .alias("presse_locale_declarative"),
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["presse_viapost"]))
                  .alias("presse_viapost_hors_meca"),
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["os"]))   .alias("trafic_os"),
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["ip"]))   .alias("trafic_ip"),
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["colis"])).alias("trafic_colis"),
              somme_si(est_distrib & F.col("co_comptage").isin(CODES["ppi"]))  .alias("trafic_ppi"),
          )
          .withColumnRenamed("lb_type_entite_regate_court", "type_site")
          .withColumn("dh_maj", F.current_timestamp())
    )

df_target = agreger_trafic_mois(df_source, MEASURE_COL)

# COMMAND ----------
# MAGIC %md ## 7. Écriture vers la cible (stratégie selon le mode)

# COMMAND ----------
from delta.tables import DeltaTable

def ecrire_cible(df: DataFrame, mode: str):
    if mode == "initial":
        (df.write
            .format("delta").mode("overwrite")
            .option("overwriteSchema", "true")
            .partitionBy("co_annee_comptage")
            .saveAsTable(TARGET_TABLE))
        print("✅ Chargement initial terminé")

    elif mode == "backfill":
        (df.write
            .format("delta").mode("overwrite")
            .option("replaceWhere",
                    f"co_annee_comptage >= {ANNEE_DEBUT} AND co_annee_comptage <= {ANNEE_FIN}")
            .partitionBy("co_annee_comptage")
            .saveAsTable(TARGET_TABLE))
        print(f"✅ Backfill terminé sur années {ANNEE_DEBUT}–{ANNEE_FIN}")

    elif mode == "incremental":
        cible = DeltaTable.forName(spark, TARGET_TABLE)
        (cible.alias("tgt")
              .merge(
                  df.alias("src"),
                  """tgt.co_annee_comptage = src.co_annee_comptage
                     AND tgt.co_mois_comptage  = src.co_mois_comptage
                     AND tgt.co_regate         = src.co_regate"""
              )
              .whenMatchedUpdateAll()
              .whenNotMatchedInsertAll()
              .execute())
        print(f"✅ Incrémental terminé ({MOIS_REFRESH} derniers mois)")

ecrire_cible(df_target, MODE)

# COMMAND ----------
# MAGIC %md ## 8. Contrôle qualité

# COMMAND ----------
display(spark.sql(f"""
    SELECT
        MIN(co_annee_comptage * 100 + co_mois_comptage) AS periode_min,
        MAX(co_annee_comptage * 100 + co_mois_comptage) AS periode_max,
        COUNT(DISTINCT co_regate) AS nb_sites,
        COUNT(*) AS nb_lignes,
        SUM(trafic_oo + presse_mecanisee + presse_locale_declarative +
            presse_viapost_hors_meca + trafic_os + trafic_ip +
            trafic_colis + trafic_ppi) AS trafic_total_global
    FROM {TARGET_TABLE}
"""))

# COMMAND ----------
# MAGIC %md ## 9. Optimisation (à lancer 1×/semaine)

# COMMAND ----------
# spark.sql(f"OPTIMIZE {TARGET_TABLE} ZORDER BY (co_regate)")
# spark.sql(f"VACUUM {TARGET_TABLE} RETAIN 168 HOURS")
